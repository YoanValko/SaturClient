package dev.zprestige.prestige;

import dev.zprestige.prestige.annotation.Chainable;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.hud.ModuleNotificationsElement;
import dev.zprestige.prestige.render.RenderContract2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/** Clean lifecycle-compatible base class shared by the bundled modules. */
public class Module extends SettingHolder implements RenderContract2 {
    private final List<Setting> coreSettings = new ArrayList<>();
    private final BoolSetting enabledSetting = new BoolSetting("Enabled", false);
    private final KeybindSetting keybind;
    private String name;
    private Category category;
    private String description;
    private boolean lastEnabled;
    private volatile List<Setting> allSettingsCache;

    public Module() {
        keybind = new KeybindSetting("Bind", -1).setDescription_KeybindSetting("Keybind for " + name);
        coreSettings.add(enabledSetting);
        coreSettings.add(keybind);
    }

    public Module(String name, String description, int categoryOrdinal) {
        this();
        this.name = name;
        this.description = description;
        Category[] values = Category.values();
        if (categoryOrdinal >= 0 && categoryOrdinal < values.length) this.category = values[categoryOrdinal];
    }

    /** Compatibility hook used by the old decompiled constructors. */
    public void a(Object ignored, String name, String description, int categoryOrdinal) {
        if (ignored instanceof Setting setting) {
            settings.add(setting);
            allSettingsCache = null;
            return;
        }
        this.name = name;
        this.description = description;
        Category[] values = Category.values();
        if (categoryOrdinal >= 0 && categoryOrdinal < values.length) this.category = values[categoryOrdinal];
    }

    @Chainable
    public boolean isEnabled() { return Boolean.TRUE.equals(enabledSetting.getValue()); }
    public int getKey(Object[] ignored) { return keybind.getValue(); }
    public KeybindSetting getKeybind(Object[] ignored) { return keybind; }

    public void toggle(Object[] ignored) {
        enabledSetting.setValue(!isEnabled());
        synchronizeLifecycle();
    }

    public void applyState(Object[] ignored) { synchronizeLifecycle(); }

    private void synchronizeLifecycle() {
        if (Prestige.eventBus == null) return;
        if (isEnabled()) {
            Prestige.eventBus.register(new Object[]{this, 0L});
            if (RenderContract2.b.world != null && RenderContract2.b.player != null) onEnable(new Object[]{0L});
            else if (Prestige.moduleManager != null) Prestige.moduleManager.queueEnable(new Object[]{this});
        } else {
            Prestige.eventBus.unregister(new Object[]{this, 0L});
            if (RenderContract2.b.world != null && RenderContract2.b.player != null) onDisable(new Object[]{0L});
            else if (Prestige.moduleManager != null) Prestige.moduleManager.queueDisable(new Object[]{this});
        }
        ModuleNotificationsElement.r(new Object[]{this, 0L});
    }

    public void dispose(Object[] ignored) {
        if (Prestige.eventBus != null) Prestige.eventBus.unregister(new Object[]{this, 0L});
        name = null;
        description = null;
        for (Setting setting : getSettings()) {
            setting.setName(new Object[]{null});
            setting.setDescription(null);
            setting.setValue(null);
        }
    }

    public void onEnable(Object[] ignored) {}
    public void onDisable(Object[] ignored) {}
    public boolean b(Object[] ignored) { return true; }
    public String getInfo(Object[] ignored) { return ""; }
    public List<Setting> getCoreSettings(Object[] ignored) { return coreSettings; }

    @Chainable public String getName() { return name; }
    public void setName(Object[] args) { name = args == null || args.length == 0 ? null : (String) args[0]; }
    @Chainable public String getDescription() { return description; }
    public void setDescription(Object[] args) { description = args == null || args.length == 0 ? null : (String) args[0]; }
    @Chainable public Category getCategory() { return category; }
    public void setCategory(Object[] args) { category = args == null || args.length == 0 ? null : (Category) args[0]; }
    public boolean getLastEnabled(Object[] ignored) { return lastEnabled; }
    public void setLastEnabled(Object[] args) { lastEnabled = args != null && args.length > 0 && Boolean.TRUE.equals(args[0]); }

    @Chainable
    public List<Setting> getSettings() {
        List<Setting> cached = allSettingsCache;
        if (cached == null) {
            List<Setting> combined = new ArrayList<>(coreSettings.size() + settings.size());
            combined.addAll(coreSettings);
            for (Object setting : settings) if (setting instanceof Setting value) combined.add(value);
            cached = Collections.unmodifiableList(combined);
            allSettingsCache = cached;
        }
        return cached;
    }

    public Set<Gamemode> getGamemodes(Object[] ignored) { return Set.of(Gamemode.Any); }

    @Chainable
    public int getGamemodeMask() {
        int mask = 0;
        for (Gamemode mode : getGamemodes(new Object[0])) if (mode != Gamemode.Any) mask |= 1 << mode.ordinal();
        return mask;
    }
}
