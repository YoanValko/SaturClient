package dev.zprestige.prestige.ui.mc;

import imgui.ImFont;
import imgui.ImFontAtlas;
import imgui.ImFontConfig;
import imgui.ImGui;
import imgui.ImGuiIO;
import imgui.gl3.ImGuiImplGl3;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import java.nio.file.Files;
import java.nio.file.Path;
import dev.zprestige.prestige.ui.Data;
import dev.zprestige.prestige.ui.Input;
import dev.zprestige.prestige.ui.Lib;
import dev.zprestige.prestige.ui.Theme;
import dev.zprestige.prestige.ui.Ui;
import dev.zprestige.prestige.gui.SafeMenuScreen;

/** Draws the ported ClickGUI over the finished frame (called from the RenderSystem.flipFrame mixin). */
public final class Overlay {
    private Overlay() {}

    public static volatile boolean visible;
    /** Mouse position in framebuffer pixels (polled from GLFW while visible; dev commands may override it). */
    public static volatile double mousePxX = -1e4, mousePxY = -1e4;

    // ---- window placement: fractions of the free space (0 = left/top edge, 1 = right/bottom edge), persisted
    static float fracX = 0.5f, fracY = 0.5f;
    static boolean posLoaded, prevDragging;
    /** config "allowUpscale": true lets the UI scale above 1 when the window is larger than 1100x700. */
    static boolean allowUpscale;
    static double dragLastX, dragLastY;
    static boolean wasGrabbed;
    static double lastRawX = Double.NaN, lastRawY = Double.NaN;
    public static volatile long lastCloseNanos;

    static Path posFile() {
        try { return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("prestige_ui.json"); } catch (Throwable t) { return null; }
    }
    static void loadPos() {
        if (posLoaded) return;
        posLoaded = true;
        try {
            Path f = posFile();
            if (f == null || !Files.exists(f)) return;
            String t = Files.readString(f);
            java.util.regex.Matcher mx = java.util.regex.Pattern.compile("\"x\"\\s*:\\s*(-?[0-9.]+)").matcher(t);
            java.util.regex.Matcher my = java.util.regex.Pattern.compile("\"y\"\\s*:\\s*(-?[0-9.]+)").matcher(t);
            if (mx.find()) fracX = Math.max(0f, Math.min(1f, Float.parseFloat(mx.group(1))));
            allowUpscale = java.util.regex.Pattern.compile("\"allowUpscale\"\\s*:\\s*true").matcher(t).find();
            if (my.find()) fracY = Math.max(0f, Math.min(1f, Float.parseFloat(my.group(1))));
        } catch (Throwable t) { System.out.println("[satur-ui] loadPos " + t); }
    }
    static void savePos() {
        try {
            Path f = posFile();
            if (f != null) Files.writeString(f, "{\"x\": " + fracX + ", \"y\": " + fracY + ", \"allowUpscale\": " + allowUpscale + "}\n");
        } catch (Throwable t) { System.out.println("[satur-ui] savePos " + t); }
    }

    // ---- open / close (no Screen involved: the game keeps rendering and updating underneath)
    public static void open() {
        if (visible) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (failed) {
            mc.setScreen(new SafeMenuScreen());
            return;
        }
        loadPos();
        wasGrabbed = mc.mouse.isCursorLocked();
        if (wasGrabbed) mc.mouse.unlockCursor();      // MouseHandler.releaseMouse
        net.minecraft.client.option.KeyBinding.unpressAll();              // KeyMapping.releaseAll: no stuck movement/attack keys
        pendingReset = true;     // Input state is reset in render() once the UI entries exist
        Input.ctrlDown = false;
        // Clipboard reads are intentionally disabled in the hardened build.
        Input.clipboard = () -> null;
        lastRawX = Double.NaN; lastRawY = Double.NaN; prevDragging = false;
        visible = true;
        pollCursor();
    }

    public static void close() {
        if (!visible) return;
        visible = false;
        lastCloseNanos = System.nanoTime();
        Input.close = false; Input.windowDragging = false; Input.mouseUp(0);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (wasGrabbed && mc.currentScreen == null && !mc.mouse.isCursorLocked()) mc.mouse.lockCursor();   // grabMouse
        wasGrabbed = false;
    }

    /** Called every client tick: keep the cursor free while the UI is open. */
    public static void tick(MinecraftClient mc) {
        if (visible && mc.mouse.isCursorLocked()) { wasGrabbed = true; mc.mouse.unlockCursor(); }
    }

    /** Read the real cursor (window coords -> framebuffer pixels). */
    static void pollCursor() {
        try {
            Window w = MinecraftClient.getInstance().getWindow();
            double[] cx = new double[1], cy = new double[1];
            org.lwjgl.glfw.GLFW.glfwGetCursorPos(w.getHandle(), cx, cy);
            if (cx[0] == lastRawX && cy[0] == lastRawY) return;
            lastRawX = cx[0]; lastRawY = cy[0];
            mousePxX = cx[0] * w.getFramebufferWidth() / Math.max(1, w.getWidth());
            mousePxY = cy[0] * w.getFramebufferHeight() / Math.max(1, w.getHeight());
        } catch (Throwable t) { /* ignore */ }
    }

    static void syncMouse() {
        pollCursor();
        Input.mx = (float) ((mousePxX - Lib.ox) / Lib.scale);
        Input.my = (float) ((mousePxY - Lib.oy) / Lib.scale);
    }

    static void afterEvent() {
        if (Input.close) { Input.close = false; close(); }
    }

    // ---- events from the MouseHandler / KeyboardHandler mixins (all return true when consumed)
    public static boolean onMouseMove() { if (!visible) return false; pollCursor(); return true; }

    public static boolean onMouseButton(int button, int action) {
        if (!visible) return false;
        syncMouse();
        if (action == 1) Input.mouseDown(button); else if (action == 0) Input.mouseUp(button);
        afterEvent();
        return true;
    }

    public static boolean onScroll(double dy) {
        if (!visible) return false;
        syncMouse();
        Input.scroll(dy);
        return true;
    }

    public static boolean onKey(int key, int action) {
        if (!visible) return false;
        if (key == 341 || key == 345) Input.ctrlDown = action != 0;
        if (action == 1 || action == 2) { syncMouse(); Input.key(key); afterEvent(); }
        return true;
    }

    public static boolean onChar(int cp) {
        if (!visible) return false;
        Input.typed(cp);
        afterEvent();
        return true;
    }

    static boolean inited, failed, pendingReset;
    static ImGuiImplGl3 gl3;
    static float bakedScale = -1f;
    static long last = System.nanoTime();

    static final String[][] FONTS = {
        {"DMSans-Medium", "26"}, {"DMSans-Medium", "29"}, {"DMSans-Regular", "20"}, {"DMSans-Regular", "17"},
        {"DMSans-Regular", "14"}, {"DMSans-Medium", "18"}, {"DMSerifDisplay-Regular", "24"}, {"DMSerifDisplay-Italic", "24"},
        {"DMSerifDisplay-Regular", "34"}, {"DMSerifDisplay-Italic", "34"}, {"DMSans-Medium", "20"}};

    static byte[] res(String path) throws Exception {
        try (InputStream in = Overlay.class.getResourceAsStream(path)) {
            if (in == null) throw new IllegalStateException("missing resource " + path);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            in.transferTo(o);
            return o.toByteArray();
        }
    }

    static void init() throws Exception {
        if (inited) return;
        ImGui.createContext();
        ImGuiIO io = ImGui.getIO();
        io.setIniFilename(null);
        gl3 = new ImGuiImplGl3();
        gl3.init("#version 150");
        Data.load(Overlay.class.getResourceAsStream("/prestige_ui/modules.tsv"), Overlay.class.getResourceAsStream("/prestige_ui/settings.tsv"));
        long[] icons = Icons.load();
        Ui.initEntries(icons);
        Theme.active = 1;
        inited = true;
    }

    /** (Re)bake the fonts at FONT_SIZE * scale. */
    static void bakeFonts(float scale) throws Exception {
        ImFontAtlas atlas = ImGui.getIO().getFonts();
        atlas.clear();
        for (int i = 0; i < FONTS.length; i++) {
            float px = Math.max(7f, Math.round(Lib.FONT_SIZE[i] * scale));
            Lib.BAKED[i] = px;
            ImFontConfig cfg = new ImFontConfig();
            cfg.setPixelSnapH(true);
            Lib.FONT[i] = atlas.addFontFromMemoryTTF(res("/prestige_ui/fonts/" + FONTS[i][0] + ".ttf"), px, cfg);
            cfg.destroy();
        }
        atlas.build();
        gl3.destroyFontsTexture();
        gl3.createFontsTexture();
        bakedScale = scale;
    }

    public static void render() {
        if (!visible || failed) return;
        try {
            init();
            Window w = MinecraftClient.getInstance().getWindow();
            int fbW = w.getFramebufferWidth(), fbH = w.getFramebufferHeight();
            if (fbW <= 0 || fbH <= 0) return;
            loadPos();
            float scale = Math.min((fbW - 24f) / 1100f, (fbH - 24f) / 700f);
            if (!(allowUpscale && fbW > 1100 && fbH > 700)) scale = Math.min(1f, scale);
            if (scale < 0.3f) scale = 0.3f;
            scale = Math.round(scale * 50f) / 50f;
            if (Math.abs(scale - bakedScale) > 0.001f) bakeFonts(scale);
            long now = System.nanoTime();
            float dt = Math.min(0.1f, (now - last) / 1e9f);
            last = now;
            ImGuiIO io = ImGui.getIO();
            io.setDisplaySize(fbW, fbH);
            io.setDeltaTime(Math.max(dt, 1e-4f));
            Lib.scale = scale;
            loadPos();
            pollCursor();
            float freeX = fbW - 1100f * scale, freeY = fbH - 700f * scale;
            float nx = freeX > 0 ? fracX * freeX : freeX * 0.5f, ny = freeY > 0 ? fracY * freeY : freeY * 0.5f;
            boolean drag = Input.windowDragging;
            if (drag && prevDragging) {
                nx += (float) (mousePxX - dragLastX); ny += (float) (mousePxY - dragLastY);
                if (freeX > 0) { nx = Math.max(0f, Math.min(freeX, nx)); fracX = nx / freeX; }
                if (freeY > 0) { ny = Math.max(0f, Math.min(freeY, ny)); fracY = ny / freeY; }
            }
            if (!drag && prevDragging) savePos();
            prevDragging = drag; dragLastX = mousePxX; dragLastY = mousePxY;
            Lib.ox = nx; Lib.oy = ny;
            Input.mx = (float) ((mousePxX - Lib.ox) / scale);
            Input.my = (float) ((mousePxY - Lib.oy) / scale);
            if (pendingReset) { pendingReset = false; Input.close = false; Input.windowDragging = false; Input.mouseUp(0); }
            Input.update(dt);
            gl3.newFrame();
            ImGui.newFrame();
            Lib.dl = ImGui.getForegroundDrawList();
            Ui.frame();
            ImGui.render();
            gl3.renderDrawData(ImGui.getDrawData());
            afterEvent();
        } catch (Throwable t) {
            failed = true;
            System.out.println("[satur-ui] overlay failed: " + t);
            t.printStackTrace(System.out);
            MinecraftClient.getInstance().setScreen(new SafeMenuScreen());
        }
    }
}
