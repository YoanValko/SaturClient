package dev.zprestige.prestige.api;

import dev.zprestige.prestige.BoolSetting;
import dev.zprestige.prestige.Category;
import dev.zprestige.prestige.ColorSetting;
import dev.zprestige.prestige.EnumSetting;
import dev.zprestige.prestige.FloatSetting;
import dev.zprestige.prestige.IntSetting;
import dev.zprestige.prestige.KeybindSetting;
import dev.zprestige.prestige.Module;
import java.awt.Color;

/** Base class for new modules written against the cleaned custom API. */
public abstract class CustomModule extends Module {
    protected CustomModule(String name, String description, Category category) {
        super(name, description, category.ordinal());
    }

    protected final BoolSetting bool(String name, boolean initial) {
        return addBool(new Object[]{name, initial});
    }

    protected final IntSetting integer(String name, int initial, int min, int max) {
        IntSetting setting = new IntSetting(name, initial, min, max);
        settings.add(setting);
        return setting;
    }

    protected final FloatSetting decimal(String name, float initial, float min, float max) {
        FloatSetting setting = new FloatSetting(name, initial, min, max);
        settings.add(setting);
        return setting;
    }

    protected final EnumSetting choice(String name, String initial, String... options) {
        return addEnum(new Object[]{name, initial, options});
    }

    protected final ColorSetting color(String name, Color initial) {
        return addColor(new Object[]{name, initial});
    }

    protected final KeybindSetting keybind(String name, int initial) {
        return addKeybind(new Object[]{name, initial});
    }

    public final boolean enabled() { return isEnabled(); }
    public final void setEnabled(boolean enabled) { ClientApi.setEnabled(this, enabled); }

    @Override public final void onEnable(Object[] ignored) { onEnable(); }
    @Override public final void onDisable(Object[] ignored) { onDisable(); }

    protected void onEnable() {}
    protected void onDisable() {}
}
