package dev.zprestige.prestige;

import java.awt.Color;
import java.util.ArrayList;

/** Common typed setting factory used by modules and the custom API. */
public class SettingHolder {
    public final ArrayList<Setting> settings = new ArrayList<>();

    public KeybindSetting addKeybind(Object[] args) {
        KeybindSetting setting = new KeybindSetting((String) args[0], (Integer) args[1]);
        settings.add(setting);
        return setting;
    }

    public BoolSetting addBool(Object[] args) {
        BoolSetting setting = new BoolSetting((String) args[0], (Boolean) args[1]);
        settings.add(setting);
        return setting;
    }

    public EnumSetting addEnum(Object[] args) {
        EnumSetting setting = new EnumSetting((String) args[0], (String) args[1], (String[]) args[2]);
        settings.add(setting);
        return setting;
    }

    public ColorSetting addColor(Object[] args) {
        ColorSetting setting = new ColorSetting((String) args[0], (Color) args[1]);
        settings.add(setting);
        return setting;
    }
}
