package dev.zprestige.prestige.ui.bridge;

import dev.zprestige.prestige.BoolSetting;
import dev.zprestige.prestige.Category;
import dev.zprestige.prestige.EnumSetting;
import dev.zprestige.prestige.FloatSetting;
import dev.zprestige.prestige.IntSetting;
import dev.zprestige.prestige.KeybindSetting;
import dev.zprestige.prestige.Module;
import dev.zprestige.prestige.MultiSetting;
import dev.zprestige.prestige.RangeSetting;
import dev.zprestige.prestige.Setting;
import dev.zprestige.prestige.api.ClientApi;
import java.util.ArrayList;
import java.util.List;

/** Typed bridge between the local GUI and the local client API. */
public final class Bridge {
    private Bridge() {}

    private static boolean tried, bound;
    private static final List<LiveModule> MODULES = new ArrayList<>();

    public static boolean available() { return bound; }
    public static List<LiveModule> modules() { return List.copyOf(MODULES); }

    public static synchronized boolean bind() {
        if (tried) return bound;
        tried = true;
        MODULES.clear();
        for (Module module : ClientApi.modules()) MODULES.add(new LiveModule(module));
        bound = !MODULES.isEmpty();
        System.out.println("[satur-ui] typed bridge " + (bound ? "bound: " + MODULES.size() + " modules" : "found no modules"));
        return bound;
    }

    public static LiveModule byName(String name) {
        if (name == null) return null;
        for (LiveModule m : MODULES) if (name.equalsIgnoreCase(m.name)) return m;
        return null;
    }

    private static String safe(String value) { return value == null ? "" : value; }

    public static final class LiveModule {
        public final Module handle;
        public final String name, desc, category;
        private final BoolSetting enabledSetting;
        private final KeybindSetting keybindSetting;
        private final List<LiveSetting> settings = new ArrayList<>();

        private LiveModule(Module module) {
            handle = module;
            name = safe(module.getName());
            desc = safe(module.getDescription());
            Category value = module.getCategory();
            category = value == null ? "Misc" : value.name();
            BoolSetting enabled = null;
            KeybindSetting keybind = null;
            for (Setting setting : module.getCoreSettings(new Object[0])) {
                if (setting instanceof BoolSetting b && "Enabled".equals(setting.getName())) enabled = b;
                if (setting instanceof KeybindSetting k && "Bind".equals(setting.getName())) keybind = k;
            }
            enabledSetting = enabled;
            keybindSetting = keybind;
            for (Setting setting : module.getSettings()) settings.add(new LiveSetting(setting));
        }

        public boolean enabled() { return handle.isEnabled(); }
        public void setEnabled(boolean value) { if (value != enabled()) handle.toggle(new Object[]{0L}); }
        public LiveSetting enabledSettingForTest() { return enabledSetting == null ? null : new LiveSetting(enabledSetting); }
        public LiveSetting keybind() { return keybindSetting == null ? null : new LiveSetting(keybindSetting); }
        public List<LiveSetting> settings() { return List.copyOf(settings); }

        public LiveSetting setting(String name) {
            if (name == null) return null;
            for (LiveSetting s : settings) if (name.equalsIgnoreCase(s.name)) return s;
            return null;
        }
    }

    public static final class LiveSetting {
        public final Setting handle;
        public final String type, name, desc;

        private LiveSetting(Setting setting) {
            handle = setting;
            type = setting.getClass().getSimpleName();
            name = safe(setting.getName());
            desc = safe(setting.getDescription());
        }

        public Object value() { return handle.getValue(); }
        public void set(Object value) { if (value != null) handle.setValue(value); }

        public float[] bounds() {
            if (handle instanceof FloatSetting f) return new float[]{f.getMin(), f.getMax()};
            if (handle instanceof IntSetting i) return new float[]{i.getMin(), i.getMax()};
            if (handle instanceof RangeSetting r) return new float[]{r.getMin(), r.getMax()};
            return new float[]{0f, 0f};
        }

        public String[] options() {
            if (handle instanceof EnumSetting e) return e.getOptions();
            if (handle instanceof MultiSetting m) return m.getOptions();
            return new String[0];
        }

        public boolean[] flags() { return handle instanceof MultiSetting m ? m.getSelected() : new boolean[0]; }
        public void setFlag(String option, boolean on) { if (handle instanceof MultiSetting m) m.setSelected(option, on); }
        public void setRangeLow(float value) { if (handle instanceof RangeSetting r) r.setLow(value); }
        public void setRangeHigh(float value) { if (handle instanceof RangeSetting r) r.setHigh(value); }
        public float rangeLow() { return handle instanceof RangeSetting r ? r.getLow() : 0f; }
        public float rangeHigh() { return handle instanceof RangeSetting r ? r.getHigh() : 0f; }
        public boolean toggleMode() { return handle instanceof KeybindSetting k && k.isToggleMode(); }
        public void setToggleMode(boolean value) { if (handle instanceof KeybindSetting k) k.setToggleMode(value); }

    }
}
