package dev.zprestige.prestige.api;

import java.util.Set;

/**
 * Hard boundaries for the local-only client API.
 *
 * <p>This is intentionally an allowlist. The bundled manifest is data, so a
 * malformed or modified manifest must not be able to make the client load an
 * arbitrary class from another package.</p>
 */
public final class SafetyPolicy {
    private static final String MODULE_PACKAGE = "dev.zprestige.prestige.module.";
    private static final int MAX_MANIFEST_MODULES = 256;
    private static final Set<String> SETTING_TYPES = Set.of(
            "dev.zprestige.prestige.BoolSetting",
            "dev.zprestige.prestige.ColorSetting",
            "dev.zprestige.prestige.EnumSetting",
            "dev.zprestige.prestige.FloatSetting",
            "dev.zprestige.prestige.IntSetting",
            "dev.zprestige.prestige.KeybindSetting",
            "dev.zprestige.prestige.MultiSetting",
            "dev.zprestige.prestige.RangeSetting",
            "dev.zprestige.prestige.TextSetting");

    private SafetyPolicy() {}

    public static boolean allowModuleClass(String className) {
        return className != null
                && className.startsWith(MODULE_PACKAGE)
                && className.indexOf("..") < 0
                && className.indexOf('/') < 0
                && className.indexOf('\\') < 0;
    }

    public static boolean allowSettingClass(String className) {
        return className != null && SETTING_TYPES.contains(className);
    }

    public static boolean allowManifestSize(int count) {
        return count >= 0 && count <= MAX_MANIFEST_MODULES;
    }

    public static String summary() {
        return "local-only; no remote module loading; no process/shell/native/credential capabilities";
    }
}
