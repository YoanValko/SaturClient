package dev.zprestige.prestige.gui;

import dev.zprestige.prestige.Module;
import dev.zprestige.prestige.api.ClientApi;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Vanilla-rendered fallback for machines where the optional ImGui/OpenGL
 * backend cannot initialize. It deliberately exposes no filesystem, network,
 * clipboard, or native capabilities.
 */
public final class SafeMenuScreen extends Screen {
    private final List<Module> modules;

    public SafeMenuScreen() {
        super(Text.literal("Satur Client"));
        modules = List.copyOf(ClientApi.modules());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int center = width / 2;
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Satur Client — safe fallback UI"), center, 24, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("The optional accelerated GUI could not initialize."), center, 42, 0xFFFFC857);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Press Escape to close. No network or account data is used."), center, 58, 0xFFB8C0CC);

        int y = 86;
        int shown = Math.min(modules.size(), 18);
        for (int i = 0; i < shown; i++) {
            Module module = modules.get(i);
            int color = module.isEnabled() ? 0xFF7DE2A8 : 0xFFCBD2DC;
            context.drawTextWithShadow(textRenderer,
                    Text.literal((module.isEnabled() ? "● " : "○ ") + module.getName()),
                    Math.max(24, center - 180), y, color);
            y += 12;
        }
        if (modules.size() > shown) {
            context.drawTextWithShadow(textRenderer, Text.literal("… and " + (modules.size() - shown) + " more"),
                    Math.max(24, center - 180), y + 4, 0xFF9AA4B2);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x();
        double y = click.y();
        int center = width / 2;
        int left = Math.max(24, center - 180);
        int row = (int)((y - 86) / 12);
        if (x >= left - 8 && x <= left + 260 && row >= 0 && row < modules.size() && y >= 82 && y < 86 + modules.size() * 12) {
            Module module = modules.get(row);
            module.toggle(new Object[]{0L});
            return true;
        }
        return super.mouseClicked(click, doubled);
    }
}
