package dev.zprestige.prestige;

import dev.zprestige.prestige.event.Event;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Small local event bus used by the custom client.
 *
 * <p>Handlers are registered only from in-process objects carrying the
 * {@link Subscribe} annotation. No class loading, network access, or native
 * dispatch is involved.</p>
 */
public final class EventBus {
    private final Map<Class<?>, CopyOnWriteArrayList<Handler>> listeners = new ConcurrentHashMap<>();
    private final Set<String> loggedFailures = ConcurrentHashMap.newKeySet();

    /** Compatibility view retained for the existing client code. */
    public final CopyOnWriteArrayList<Object> e = new CopyOnWriteArrayList<>();

    public void register(Object[] args) {
        if (args == null || args.length == 0 || args[0] == null) return;
        Object target = args[0];
        if (!target.getClass().getName().startsWith("dev.zprestige.prestige.")) return;
        Set<String> seen = new HashSet<>();
        for (Class<?> type = target.getClass(); type != null && type != Object.class; type = type.getSuperclass()) {
            for (Method method : type.getDeclaredMethods()) {
                if (!method.isAnnotationPresent(Subscribe.class)
                        || Modifier.isStatic(method.getModifiers())
                        || method.getParameterCount() != 1) continue;
                Class<?> eventType = method.getParameterTypes()[0];
                if (!eventType.getName().startsWith("dev.zprestige.prestige.event.")) continue;
                String signature = method.getName() + method.toGenericString();
                if (!seen.add(signature)) continue;
                try {
                    method.setAccessible(true);
                    Handler handler = new Handler(target, method, eventType);
                    CopyOnWriteArrayList<Handler> bucket = listeners.computeIfAbsent(
                            eventType, ignored -> new CopyOnWriteArrayList<>());
                    boolean duplicate = bucket.stream().anyMatch(existing -> existing.target == target
                            && existing.method.equals(method));
                    if (!duplicate) bucket.add(handler);
                } catch (Throwable error) {
                    logFailure(target, method, error);
                }
            }
        }
        if (listeners.values().stream().anyMatch(bucket -> bucket.stream().anyMatch(h -> h.target == target))) {
            e.addIfAbsent(target);
        }
    }

    public void unregister(Object[] args) {
        if (args == null || args.length == 0 || args[0] == null) return;
        Object target = args[0];
        for (CopyOnWriteArrayList<Handler> bucket : listeners.values()) {
            bucket.removeIf(handler -> handler.target == target);
        }
        listeners.entrySet().removeIf(entry -> entry.getValue().isEmpty());
        e.remove(target);
    }

    public boolean post(Object[] args) {
        if (args == null || args.length == 0 || !(args[0] instanceof Event event)) return false;
        CopyOnWriteArrayList<Handler> bucket = listeners.get(event.getClass());
        if (bucket != null) {
            for (Handler handler : bucket) {
                try {
                    handler.method.invoke(handler.target, event);
                } catch (Throwable error) {
                    logFailure(handler.target, handler.method, unwrap(error));
                }
            }
        }
        return event.a_boolean___(new Object[0]);
    }

    public boolean hasListeners(Object[] args) {
        if (args == null || args.length == 0 || !(args[0] instanceof Class<?> type)) return false;
        CopyOnWriteArrayList<Handler> bucket = listeners.get(type);
        return bucket != null && !bucket.isEmpty();
    }

    public boolean hasListenerOfType(Object[] args) {
        if (args == null || args.length < 2 || !(args[0] instanceof Class<?> eventType)
                || !(args[1] instanceof Class<?> objectType)) return false;
        CopyOnWriteArrayList<Handler> bucket = listeners.get(eventType);
        if (bucket == null) return false;
        return bucket.stream().anyMatch(handler -> objectType.isInstance(handler.target));
    }

    private void logFailure(Object target, Method method, Throwable error) {
        String key = target.getClass().getName() + '#' + method.getName() + ':' + error.getClass().getName();
        if (loggedFailures.add(key)) {
            System.err.println("[Satur/EventBus] handler failed: " + key);
            error.printStackTrace(System.err);
        }
    }

    private static Throwable unwrap(Throwable error) {
        if (error instanceof java.lang.reflect.InvocationTargetException invocation
                && invocation.getCause() != null) return invocation.getCause();
        return error;
    }

    private record Handler(Object target, Method method, Class<?> eventType) {}
}
