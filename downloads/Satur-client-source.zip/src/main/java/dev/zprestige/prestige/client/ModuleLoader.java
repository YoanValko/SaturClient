package dev.zprestige.prestige.client;

import dev.zprestige.prestige.Module;
import dev.zprestige.prestige.ui.bridge.Bootstrap;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the bundled module set from the local manifest.
 *
 * <p>This is deliberately local-only: it reads a packaged resource and never
 * downloads code, contacts a server, or invokes the removed native injector.</p>
 */
public final class ModuleLoader {
    private ModuleLoader() {}

    public static List<Module> load(ClassLoader loader) {
        List<Module> modules = new ArrayList<>();
        int failed = 0;
        for (Bootstrap.Mod entry : Bootstrap.mods().values()) {
            try {
                Class<?> type = Bootstrap.loadModuleClass(entry.clazz, loader);
                if (!Module.class.isAssignableFrom(type)) {
                    failed++;
                    System.out.println("[satur] skipped non-module entry: " + entry.clazz);
                    continue;
                }
                Constructor<?> constructor = type.getDeclaredConstructor();
                constructor.setAccessible(true);
                Module module = (Module) constructor.newInstance();
                Bootstrap.post(module);
                modules.add(module);
            } catch (Throwable error) {
                failed++;
                Throwable cause = error instanceof InvocationTargetException && error.getCause() != null
                        ? error.getCause() : error;
                if (failed <= 5) {
                    System.out.println("[satur] module load failed: " + entry.clazz + " -> " + cause);
                }
            }
        }
        System.out.println("[satur] loaded " + modules.size() + " modules; failed " + failed);
        return modules;
    }
}
