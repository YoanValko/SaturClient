# Saturn Client Alpha

Saturn Client Alpha is a Minecraft 1.21.11 Fabric client-side customization project with a draggable GUI, shaders, HUD tools, and modular gameplay utilities.

This Alpha build is a rebrand and resource-namespace port of the supplied Kuro source. The internal `dev.kuro` package namespace is intentionally preserved to reduce compatibility risk; it is not a claim that the code originated here. Review the upstream license and retain required attribution before redistribution.

## Build

- Java 21
- Minecraft 1.21.11
- Fabric Loader 0.20.1
- Fabric API 0.141.5+1.21.11

Use a disposable test profile or Windows Sandbox. From the project directory:

```powershell
gradle build --no-daemon
```

The remapped JAR is written to `build/libs/saturn-client-alpha-1.0.0-alpha.jar`.

## Safety scope

The supplied source was statically reviewed for process spawning, native loading, raw network clients, webhooks, credential/browser access, persistence, and self-delete behavior. No matches were found in the reviewed source. The project still has normal Minecraft network behavior through the game/Fabric APIs, local config/profile writes, clipboard features, reflection for its event bus, and third-party build dependencies. These are not a proof of safety. Test offline, do not use real credentials, and verify each future change independently.
