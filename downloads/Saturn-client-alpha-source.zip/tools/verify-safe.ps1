[CmdletBinding()]
param(
    [string]$SourceRoot
)

$ErrorActionPreference = 'Stop'
$scriptRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
if ([string]::IsNullOrWhiteSpace($SourceRoot)) { $SourceRoot = Join-Path $scriptRoot '..\src\main\java' }
$root = (Resolve-Path $SourceRoot).Path
$files = Get-ChildItem -LiteralPath $root -Recurse -Filter '*.java' -File

# Capabilities not required by the local-only client. Treat these as failures
# if they are introduced into the Java source later.
$forbidden = @(
    'ProcessBuilder',
    'Runtime\.getRuntime\(\)\.(exec|halt|exit)',
    'System\.(load|loadLibrary)',
    'java\.net\.(Socket|ServerSocket|URL|HttpURLConnection)',
    'java\.net\.http\.HttpClient',
    'java\.nio\.channels\.SocketChannel',
    'webhook',
    'access.?token',
    'browser.*(cookie|profile)',
    'self.?destruct'
)

$warnings = @(
    'Class\.forName',
    'setAccessible',
    'java\.nio\.file\.(Files|Paths)',
    'clipboard',
    'sun\.misc\.Unsafe',
    'org\.lwjgl\.glfw\.GLFW'
)

$failures = [System.Collections.Generic.List[string]]::new()
$notes = [System.Collections.Generic.List[string]]::new()
foreach ($file in $files) {
    $lineNumber = 0
    foreach ($line in Get-Content -LiteralPath $file.FullName) {
        $lineNumber++
        foreach ($pattern in $forbidden) {
            if ($line -match $pattern) {
                $failures.Add("FORBIDDEN $($file.FullName):$lineNumber matches $pattern")
            }
        }
        foreach ($pattern in $warnings) {
            if ($line -match $pattern) {
                $notes.Add("REVIEW $($file.FullName):$lineNumber matches $pattern")
            }
        }
    }
}

Write-Output "Scanned $($files.Count) Java files under $root"
if ($notes.Count -gt 0) {
    Write-Output 'Review-only findings:'
    $notes | Sort-Object -Unique | ForEach-Object { Write-Output $_ }
}
if ($failures.Count -gt 0) {
    Write-Output 'Forbidden capability findings:'
    $failures | Sort-Object -Unique | ForEach-Object { Write-Output $_ }
    exit 1
}
Write-Output 'PASS: no forbidden process, native-loader, raw-network, credential, or self-destruct patterns found.'
