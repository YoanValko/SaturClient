package dev.satur.client.data;

import dev.satur.client.render.VertexFormat;

public record VertexIntData(VertexFormat bf, int bg, int bh) {
}
