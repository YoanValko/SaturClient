package dev.satur.client.event;

public class TickEvent2 extends Event {
}
