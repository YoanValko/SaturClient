package dev.satur.client.data;

import dev.satur.client.Module;

public record ModuleStringFloatData(Module a_, String ba, float bb) {
}
