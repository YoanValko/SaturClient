package dev.satur.client.event;

import dev.satur.client.type.EventPhase;
import net.minecraft.entity.Entity;

public class EntityEvent4 extends Event {
    public final Entity a;

    public EntityEvent4(Entity var1, EventPhase var2) {
        super(var2);
        this.a = var1;
    }
}
