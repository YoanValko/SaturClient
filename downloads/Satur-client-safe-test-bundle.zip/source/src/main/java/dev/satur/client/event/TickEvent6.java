package dev.satur.client.event;

public class TickEvent6 extends Event {
}
