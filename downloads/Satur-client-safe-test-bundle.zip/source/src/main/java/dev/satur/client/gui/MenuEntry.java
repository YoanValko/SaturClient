package dev.satur.client.gui;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Opens the native Minecraft-rendered Satur menu with Right Shift. */
public final class MenuEntry implements ClientModInitializer {
    private boolean previous;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        System.out.println("[satur-ui] native Java menu loaded (Right Shift opens it)");
    }

    private void tick(MinecraftClient client) {
        try {
            long window = client.getWindow().getHandle();
            boolean down = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !previous && !(client.currentScreen instanceof SafeMenuScreen)) {
                client.setScreen(new SafeMenuScreen());
            }
            previous = down;
        } catch (Throwable error) {
            System.out.println("[satur-ui] menu tick " + error);
        }
    }
}
