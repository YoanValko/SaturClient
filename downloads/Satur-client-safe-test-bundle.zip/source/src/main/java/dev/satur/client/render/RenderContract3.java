package dev.satur.client.render;

public interface RenderContract3 {
    RenderBatch a(Object[] var1);

    default int a() {
        return 0;
    }
}
