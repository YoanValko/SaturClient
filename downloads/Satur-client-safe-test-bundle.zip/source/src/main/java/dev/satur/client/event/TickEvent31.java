package dev.satur.client.event;

public class TickEvent31 extends Event {
}
