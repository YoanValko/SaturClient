package dev.satur.client.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class NameTags {
    public NameTags() {
        dev.satur.client.api.bridge.Bootstrap.pre(this);
    }

    public String a;
    public Color b;
    public int c;
    public String d;
    public float e;
    public float f;
    public Color g;
    public String h;
    public float i;
    public float j;
    public float k;
    public List l = new ArrayList();
    public List m = new ArrayList();
}
