package dev.satur.client.event;

public class TickEvent4 extends Event {
}
