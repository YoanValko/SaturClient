package dev.satur.client.gui;

import dev.satur.client.Category;
import dev.satur.client.Module;
import dev.satur.client.api.ClientApi;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Local Minecraft-rendered ClickGUI inspired by the supplied marketplace design. */
public final class SafeMenuScreen extends Screen {
    private static final int ACCENT = 0xFF4677FF;
    private static final int PANEL = 0xE817181F;
    private static final int CARD = 0xE822232C;
    private final List<Module> modules;
    private Category selectedCategory = Category.Combat;
    private int scroll;

    public SafeMenuScreen() {
        super(Text.literal("Satur Client"));
        modules = List.copyOf(ClientApi.modules());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = Math.max(18, width / 2 - 310);
        int top = Math.max(18, height / 2 - 180);
        int right = Math.min(width - 18, left + 620);
        int bottom = Math.min(height - 18, top + 360);
        context.fill(left, top, right, bottom, 0xD908090D);
        context.fill(left, top, left + 132, bottom, PANEL);
        context.fill(left + 132, top, right, top + 58, PANEL);
        context.drawTextWithShadow(textRenderer, Text.literal("SATUR CLIENT"), left + 18, top + 18, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("BETA / LOCAL UI"), left + 18, top + 34, 0xFF9AA4B2);
        context.drawTextWithShadow(textRenderer, Text.literal(selectedCategory.name()), left + 154, top + 20, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("Right Shift closes · click cards to toggle"), left + 154, top + 36, 0xFF9AA4B2);

        int categoryY = top + 76;
        for (Category category : Category.values()) {
            boolean active = category == selectedCategory;
            if (active) context.fill(left + 10, categoryY - 4, left + 122, categoryY + 16, ACCENT);
            context.drawTextWithShadow(textRenderer, Text.literal(category.name()), left + 20, categoryY, active ? 0xFFFFFFFF : 0xFFB8C0CC);
            categoryY += 24;
        }

        List<Module> visible = new ArrayList<>();
        for (Module module : modules) if (module.getCategory() == selectedCategory) visible.add(module);
        int contentLeft = left + 150;
        int contentTop = top + 76 - scroll;
        int cardWidth = 205;
        int cardHeight = 48;
        for (int i = 0; i < visible.size(); i++) {
            Module module = visible.get(i);
            int x = contentLeft + (i % 2) * (cardWidth + 12);
            int y = contentTop + (i / 2) * (cardHeight + 10);
            if (y + cardHeight < top + 62 || y > bottom - 8) continue;
            context.fill(x, y, x + cardWidth, y + cardHeight, module.isEnabled() ? 0xE82D4A73 : CARD);
            context.fill(x, y, x + 3, y + cardHeight, module.isEnabled() ? ACCENT : 0xFF454852);
            context.drawTextWithShadow(textRenderer, Text.literal(module.getName()), x + 12, y + 10, 0xFFFFFFFF);
            String description = module.getDescription() == null ? "No description" : module.getDescription();
            if (description.length() > 29) description = description.substring(0, 29) + "…";
            context.drawTextWithShadow(textRenderer, Text.literal(description), x + 12, y + 26, 0xFFB8C0CC);
        }
        context.drawTextWithShadow(textRenderer, Text.literal("Local Java GUI · no third-party backend"), left + 150, bottom - 18, 0xFF7E8796);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x();
        double y = click.y();
        int left = Math.max(18, width / 2 - 310);
        int top = Math.max(18, height / 2 - 180);
        int categoryY = top + 76;
        for (Category category : Category.values()) {
            if (x >= left + 8 && x <= left + 126 && y >= categoryY - 6 && y <= categoryY + 18) {
                selectedCategory = category;
                scroll = 0;
                return true;
            }
            categoryY += 24;
        }
        List<Module> visible = new ArrayList<>();
        for (Module module : modules) if (module.getCategory() == selectedCategory) visible.add(module);
        int contentLeft = left + 150;
        int contentTop = top + 76 - scroll;
        for (int i = 0; i < visible.size(); i++) {
            int x0 = contentLeft + (i % 2) * 217;
            int y0 = contentTop + (i / 2) * 58;
            if (x >= x0 && x <= x0 + 205 && y >= y0 && y <= y0 + 48) {
                visible.get(i).toggle(new Object[]{0L});
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, scroll - (int) (verticalAmount * 24));
        return true;
    }
}
