package dev.satur.client.event;

public class TickEvent8 extends Event {
}
