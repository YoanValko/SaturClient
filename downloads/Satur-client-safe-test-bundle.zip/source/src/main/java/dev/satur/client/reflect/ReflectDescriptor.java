package dev.satur.client.reflect;

public record ReflectDescriptor(Class<?> aN, String aO, Object aP, Class<?> aQ) {
}
