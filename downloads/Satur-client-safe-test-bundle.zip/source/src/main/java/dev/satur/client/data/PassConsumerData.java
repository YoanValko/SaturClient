package dev.satur.client.data;

import dev.satur.client.render.RenderPass;
import java.util.function.Consumer;

public record PassConsumerData(RenderPass bx, Consumer by) {
}
