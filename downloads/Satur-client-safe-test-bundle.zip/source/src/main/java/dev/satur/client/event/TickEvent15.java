package dev.satur.client.event;

public class TickEvent15 extends Event {
}
