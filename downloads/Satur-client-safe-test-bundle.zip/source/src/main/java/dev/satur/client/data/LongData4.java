package dev.satur.client.data;

import net.minecraft.util.math.BlockPos;

public record LongData4(BlockPos ay, long az) {
}
