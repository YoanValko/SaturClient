package dev.satur.client;

import dev.satur.client.annotation.Chainable;
import java.util.function.Predicate;

/** Base value holder for the custom module settings API. */
public abstract class Setting {
    private String name;
    private Object value;
    private String description;
    private Predicate<Object> visibility;
    private static int[] compatibilityState;

    protected Setting(String name, Object value) {
        this.name = name;
        this.value = value;
    }

    @Chainable public String getName() { return name; }
    public void setName(Object[] args) { name = args == null || args.length == 0 ? null : (String) args[0]; }
    @Chainable public Object getValue() { return value; }
    @Chainable public void setValue(Object value) { this.value = value; }
    @Chainable public String getDescription() { return description; }

    @Chainable
    public Setting setDescription(String description) {
        this.description = description;
        return this;
    }

    @SuppressWarnings("unchecked")
    public Setting setVisibility(Object[] args) {
        visibility = args != null && args.length > 0 ? (Predicate<Object>) args[0] : null;
        return this;
    }

    @Chainable
    public boolean isVisible() { return visibility == null || visibility.test(value); }

    /** Legacy compatibility storage; not used for code loading or dispatch. */
    public static void b(int[] state) { compatibilityState = state; }
    public static int[] b() { return compatibilityState; }
}
