package dev.satur.client.event;

public class TickEvent12 extends Event {
}
