package dev.satur.client.render;

import dev.satur.client.config.ConfigHelper2;

@FunctionalInterface
public interface RenderContract {
    boolean a(int var1, ConfigHelper2 var2);
}
