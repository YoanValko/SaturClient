package dev.satur.client.event;

public class TickEvent14 extends Event {
}
