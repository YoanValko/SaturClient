package dev.satur.client.event;

public class TickEvent3 extends Event {
}
