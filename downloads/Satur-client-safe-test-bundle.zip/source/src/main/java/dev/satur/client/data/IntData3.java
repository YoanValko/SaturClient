package dev.satur.client.data;

public record IntData3(int b5, int b6, int b7, int b8) {
}
