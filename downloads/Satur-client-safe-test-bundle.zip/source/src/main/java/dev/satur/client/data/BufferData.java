package dev.satur.client.data;

import dev.satur.client.render.GpuBuffer;
import dev.satur.client.render.RenderHelper31;
import java.util.concurrent.atomic.AtomicReference;

public record BufferData(GpuBuffer au, GpuBuffer av, RenderHelper31 aw, AtomicReference ax) {
}
