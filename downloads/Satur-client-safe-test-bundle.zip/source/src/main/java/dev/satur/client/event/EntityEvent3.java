package dev.satur.client.event;

import dev.satur.client.type.EventPhase;
import net.minecraft.entity.Entity;

public class EntityEvent3 extends Event {
    private final Entity a;

    public EntityEvent3(Entity var1, EventPhase var2) {
        super(var2);
        this.a = var1;
    }

    public Entity a(Object[] var1) {
        return this.a;
    }
}
