package dev.satur.client.data;

public record IntBoolData(int cg, int ch, int ci, boolean cj) {
}
