package dev.satur.client.event;

public class TickEvent7 extends Event {
}
