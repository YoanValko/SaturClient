package dev.satur.client.module.movement;

import dev.satur.client.Module;
import dev.satur.client.RangeSetting;
import dev.satur.client.Subscribe;
import dev.satur.client.event.TickEvent19;
import dev.satur.client.render.RenderUtil2;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.util.math.Box;

public class Parkour extends Module {
    public Parkour() {
        dev.satur.client.api.bridge.Bootstrap.pre(this);
    }

    private RangeSetting a;

    @Subscribe
    public void a(TickEvent19 var1) {
        if (b.player.isOnGround() && !b.options.jumpKey.isPressed()) {
            if (!b.player.isSneaking() && !b.options.sneakKey.isPressed()) {
                Box var9 = b.player.getBoundingBox();
                Box var10 = var9.offset(0.0, -0.5, 0.0)
                    .expand(-this.a.randomInRange(new Object[]{877569900989L}) / 100.0, 0.0, -this.a.randomInRange(new Object[]{877569900989L}) / 100.0);
                if (!b.world.getBlockCollisions(b.player, var10).iterator().hasNext()) {
                    RenderUtil2.a(new Object[]{134150376721510L});
                }
            }
        }
    }

    private static Field g(Class var0, String var1, Class var2) {
        for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
                return var6;
            }
        }

        return null;
    }

    private static Field h(Class var0, String var1, Class var2) {
        Field var3 = g(var0, var1, var2);
        if (var3 != null) {
            return var3;
        } else {
            Class[] var4 = var0.getInterfaces();
            if (var4 != null) {
                for (int var5 = 0; var5 < var4.length; var5++) {
                    var3 = h(var4[var5], var1, var2);
                    if (var3 != null) {
                        return var3;
                    }
                }
            }

            return null;
        }
    }

    private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
        label33:
        for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
                Class[] var9 = var8.getParameterTypes();
                if (var9.length == var3) {
                    for (int var10 = 0; var10 < var3; var10++) {
                        if (var9[var10] != var4[var10]) {
                            continue label33;
                        }
                    }

                    return var8;
                }
            }
        }

        return null;
    }

    private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
        Method var5 = g(var0, var1, var2, var3, var4);
        if (var5 != null) {
            return var5;
        } else {
            Class[] var6 = var0.getInterfaces();
            if (var6 != null) {
                for (int var7 = 0; var7 < var6.length; var7++) {
                    var5 = h(var6[var7], var1, var2, var3, var4);
                    if (var5 != null) {
                        return var5;
                    }
                }
            }

            return null;
        }
    }
}
