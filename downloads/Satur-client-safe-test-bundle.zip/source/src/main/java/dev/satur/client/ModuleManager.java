package dev.satur.client;

import dev.satur.client.client.SaturClient;
import dev.satur.client.event.TickEvent19;
import dev.satur.client.render.RenderContract2;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Local registry and lifecycle coordinator for the custom module API. */
public final class ModuleManager implements RenderContract2 {
    private final MenuModule menu;
    private volatile List<Module> modules = List.of();
    private final ConcurrentLinkedQueue<Module> enableQueue = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<Module> disableQueue = new ConcurrentLinkedQueue<>();

    /** Compatibility flag retained for older module code. */
    public static boolean f = true;

    public ModuleManager(long ignored) {
        menu = new MenuModule();
        SaturClient.eventBus.register(new Object[]{this, 0L});
    }

    @Subscribe
    public void onTick(TickEvent19 event) {
        if (b.world == null || b.player == null) return;
        drain(enableQueue, true);
        drain(disableQueue, false);
    }

    private void drain(ConcurrentLinkedQueue<Module> queue, boolean enable) {
        Module module;
        while ((module = queue.poll()) != null) {
            if (enable && module.isEnabled()) module.onEnable(new Object[]{0L});
            if (!enable && !module.isEnabled()) module.onDisable(new Object[]{0L});
        }
    }

    public void queueEnable(Object[] args) {
        if (args != null && args.length > 0 && args[0] instanceof Module module && !enableQueue.contains(module)) {
            enableQueue.offer(module);
        }
    }

    public void queueDisable(Object[] args) {
        if (args != null && args.length > 0 && args[0] instanceof Module module && !disableQueue.contains(module)) {
            disableQueue.offer(module);
        }
    }

    public List<Module> getModules() { return modules; }

    public void setModules(List modules) {
        List<Module> copy = new ArrayList<>();
        if (modules != null) {
            for (Object value : modules) if (value instanceof Module module) copy.add(module);
        }
        this.modules = Collections.unmodifiableList(copy);
    }

    public MenuModule getMenu(Object[] ignored) { return menu; }

    public void setMenuColor(Color color) {
        if (color != null) menu.getMenuColor(new Object[0]).setValue(color);
    }

    public void setMenuKey(int key) { menu.getMenuKey(new Object[0]).setValue(key); }
}
