package dev.satur.client.data;

import dev.satur.client.render.GpuBuffer;

public record BufferQuadIntData(GpuBuffer cc, IntBoolData cd, int ce, long cf) {
}
