package dev.satur.client.math;

import net.minecraft.util.math.Vec3d;

public class TrailsHelper {
    public Vec3d a;
    public boolean b = true;
}
