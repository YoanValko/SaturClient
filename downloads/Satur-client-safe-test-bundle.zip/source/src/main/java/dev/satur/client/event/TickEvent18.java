package dev.satur.client.event;

public class TickEvent18 extends Event {
}
