package dev.satur.client.data;

public record FloatDoubleIntData(float bt, double bu, int bv, double bw) {
}
