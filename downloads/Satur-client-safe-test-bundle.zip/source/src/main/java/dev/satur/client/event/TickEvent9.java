package dev.satur.client.event;

public class TickEvent9 extends Event {
}
