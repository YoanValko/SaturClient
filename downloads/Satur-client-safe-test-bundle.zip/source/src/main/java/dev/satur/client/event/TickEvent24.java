package dev.satur.client.event;

import dev.satur.client.data.MatrixCameraData;
import dev.satur.client.render.RenderHelper8;

public class TickEvent24 extends Event {
    public final RenderHelper8 a;
    public final MatrixCameraData b;

    public TickEvent24(RenderHelper8 var1, MatrixCameraData var2) {
        this.a = var1;
        this.b = var2;
    }
}
