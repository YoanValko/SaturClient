package dev.satur.client.event;

public class TickEvent17 extends Event {
}
