package dev.satur.client.data;

import com.google.gson.JsonElement;
import dev.satur.client.Module;

public record ModuleStringBoolData(Module aC, String aD, JsonElement aE, boolean aF) {
}
