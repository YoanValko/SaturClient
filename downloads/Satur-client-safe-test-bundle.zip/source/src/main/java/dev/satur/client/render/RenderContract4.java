package dev.satur.client.render;

import dev.satur.client.data.VectorData;

public interface RenderContract4 {
    void a(Object[] var1);

    VectorData a_VectorData_(Object[] var1);
}
