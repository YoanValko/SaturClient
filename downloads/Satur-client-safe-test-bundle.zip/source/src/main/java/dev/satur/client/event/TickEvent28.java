package dev.satur.client.event;

public class TickEvent28 extends Event {
}
