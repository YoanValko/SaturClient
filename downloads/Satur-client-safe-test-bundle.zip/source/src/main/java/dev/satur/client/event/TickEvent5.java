package dev.satur.client.event;

public class TickEvent5 extends Event {
}
