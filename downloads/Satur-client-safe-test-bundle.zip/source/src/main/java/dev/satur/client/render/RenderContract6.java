package dev.satur.client.render;

import dev.satur.client.data.MatrixCameraData;

public interface RenderContract6 {
    void a(RenderHelper8 var1, MatrixCameraData var2);
}
