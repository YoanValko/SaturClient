package dev.satur.client.data;

import net.minecraft.util.math.Vec3d;

public record VecIntData(Vec3d a, int b) {
}
