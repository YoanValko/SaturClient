package dev.satur.client.data;

import net.minecraft.network.packet.Packet;

public record LongData3(Packet<?> as, long at) {
}
