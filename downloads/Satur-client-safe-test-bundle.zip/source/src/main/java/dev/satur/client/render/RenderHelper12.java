package dev.satur.client.render;

public class RenderHelper12 {
    public float a;
}
