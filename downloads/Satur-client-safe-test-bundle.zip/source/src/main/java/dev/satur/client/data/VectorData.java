package dev.satur.client.data;

import dev.satur.client.render.DrawMode;
import org.joml.Vector4f;

public record VectorData(Vector4f bD, DrawMode bE) {
}
