package dev.satur.client.api;

import java.util.Set;

/**
 * Hard boundaries for the local-only client API.
 *
 * <p>This is intentionally an allowlist. The bundled manifest is data, so a
 * malformed or modified manifest must not be able to make the client load an
 * arbitrary class from another package.</p>
 */
public final class SafetyPolicy {
    private static final String MODULE_PACKAGE = "dev.satur.client.module.";
    private static final int MAX_MANIFEST_MODULES = 256;
    private static final Set<String> SETTING_TYPES = Set.of(
            "dev.satur.client.BoolSetting",
            "dev.satur.client.ColorSetting",
            "dev.satur.client.EnumSetting",
            "dev.satur.client.FloatSetting",
            "dev.satur.client.IntSetting",
            "dev.satur.client.KeybindSetting",
            "dev.satur.client.MultiSetting",
            "dev.satur.client.RangeSetting",
            "dev.satur.client.TextSetting");

    private SafetyPolicy() {}

    public static boolean allowModuleClass(String className) {
        return className != null
                && className.startsWith(MODULE_PACKAGE)
                && className.indexOf("..") < 0
                && className.indexOf('/') < 0
                && className.indexOf('\\') < 0;
    }

    public static boolean allowSettingClass(String className) {
        return className != null && SETTING_TYPES.contains(className);
    }

    public static boolean allowManifestSize(int count) {
        return count >= 0 && count <= MAX_MANIFEST_MODULES;
    }

    public static String summary() {
        return "local-only; no remote module loading; no process/shell/native/credential capabilities";
    }
}
