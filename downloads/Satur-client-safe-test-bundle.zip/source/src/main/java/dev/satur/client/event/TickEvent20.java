package dev.satur.client.event;

public class TickEvent20 extends Event {
}
