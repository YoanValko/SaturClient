package dev.satur.client.event;

import dev.satur.client.type.EventPhase;

public class TickEvent16 extends Event {
    public TickEvent16(EventPhase var1) {
        super(var1);
    }
}
