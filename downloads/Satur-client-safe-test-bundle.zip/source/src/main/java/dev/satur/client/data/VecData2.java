package dev.satur.client.data;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record VecData2(BlockPos ae, Vec3d af) {
}
