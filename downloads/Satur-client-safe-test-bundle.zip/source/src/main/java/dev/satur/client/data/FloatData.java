package dev.satur.client.data;

import net.minecraft.entity.Entity;

public record FloatData(Entity ag, float ah, float ai) {
}
