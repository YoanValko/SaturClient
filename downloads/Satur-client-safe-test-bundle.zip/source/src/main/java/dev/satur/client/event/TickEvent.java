package dev.satur.client.event;

public class TickEvent extends Event {
}
