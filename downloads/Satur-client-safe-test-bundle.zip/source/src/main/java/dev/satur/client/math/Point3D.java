package dev.satur.client.math;

import dev.satur.client.combat.TwoDESPHelper;

public final class Point3D {
    public float a;
    public float b;
    public float c;
    public float d;
    public float e;
    public long f;
    public TwoDESPHelper g;
}
