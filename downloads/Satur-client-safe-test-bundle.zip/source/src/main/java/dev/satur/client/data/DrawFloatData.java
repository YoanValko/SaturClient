package dev.satur.client.data;

import dev.satur.client.render.RenderContract4;

public record DrawFloatData(RenderContract4 ca, float cb) {
}
