package dev.satur.client.event;

public class TickEvent23 extends Event {
}
