package dev.satur.client.data;

import net.minecraft.util.math.BlockPos;

public record LongData2(BlockPos aj, long ak) {
}
