package dev.satur.client.data;

import net.minecraft.util.math.Vec3d;

public record VecIntData2(Vec3d aA, int aB) {
}
