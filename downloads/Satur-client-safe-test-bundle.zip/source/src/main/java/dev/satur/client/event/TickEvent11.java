package dev.satur.client.event;

public class TickEvent11 extends Event {
}
