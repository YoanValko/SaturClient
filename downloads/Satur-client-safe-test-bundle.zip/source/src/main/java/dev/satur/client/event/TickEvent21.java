package dev.satur.client.event;

public class TickEvent21 extends Event {
}
