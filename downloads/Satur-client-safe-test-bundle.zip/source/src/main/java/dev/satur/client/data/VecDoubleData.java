package dev.satur.client.data;

import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.Vec3d;

public record VecDoubleData(TntMinecartEntity ao, Vec3d ap, double aq, double ar) {
}
