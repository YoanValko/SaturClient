package dev.satur.client.api;

import dev.satur.client.EventBus;
import dev.satur.client.Module;
import dev.satur.client.ModuleManager;
import dev.satur.client.client.SaturClient;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;

/** Public, local-only API for custom modules and extensions. */
public final class ClientApi {
    private ClientApi() {}

    public static MinecraftClient minecraft() {
        return MinecraftClient.getInstance();
    }

    public static EventBus events() {
        return SaturClient.eventBus;
    }

    public static ModuleManager moduleManager() {
        return SaturClient.moduleManager;
    }

    public static List<Module> modules() {
        ModuleManager manager = moduleManager();
        return manager == null ? List.of() : manager.getModules();
    }

    public static Optional<Module> findModule(String name) {
        if (name == null) return Optional.empty();
        return modules().stream()
                .filter(module -> name.equalsIgnoreCase(module.getName()))
                .findFirst();
    }

    public static boolean setEnabled(Module module, boolean enabled) {
        if (module == null || module.isEnabled() == enabled) return false;
        module.toggle(new Object[]{0L});
        return module.isEnabled() == enabled;
    }

    public static boolean inWorld() {
        MinecraftClient mc = minecraft();
        return mc != null && mc.world != null && mc.player != null;
    }
}
