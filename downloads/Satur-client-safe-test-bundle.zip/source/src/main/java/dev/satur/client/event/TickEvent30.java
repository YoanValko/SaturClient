package dev.satur.client.event;

public class TickEvent30 extends Event {
}
