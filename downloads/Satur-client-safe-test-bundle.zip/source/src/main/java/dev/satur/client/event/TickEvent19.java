package dev.satur.client.event;

public class TickEvent19 extends Event {
}
