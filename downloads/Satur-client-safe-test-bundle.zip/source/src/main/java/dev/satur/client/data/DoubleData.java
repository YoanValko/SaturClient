package dev.satur.client.data;

import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public record DoubleData(BlockPos al, BlockHitResult am, double an) {
}
