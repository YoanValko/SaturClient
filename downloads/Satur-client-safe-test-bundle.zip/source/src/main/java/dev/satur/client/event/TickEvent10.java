package dev.satur.client.event;

public class TickEvent10 extends Event {
}
