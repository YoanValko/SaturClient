package dev.satur.client.event;

public class TickEvent26 extends Event {
}
