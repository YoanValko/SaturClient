# Satur Client

Satur Client is a local-only Fabric 1.21.11 client built from the reviewed source tree. It keeps the existing GUI and module compatibility layer while removing the injector, native loader, remote module/config paths, self-destruct behavior, and other unnecessary attack surface.

## Safety model

- Modules and the API are loaded from bundled local resources only.
- No remote module service, webhook, browser credential access, process spawning, or native code loader is included.
- The original legacy Java package names are preserved so existing module and GUI compatibility code continues to resolve.
- This is a source review and hardening pass, not a guarantee that future changes or third-party dependencies are safe.

Module classes are loaded only from the bundled `dev.satur.client.module.*` allowlist. Run `powershell -ExecutionPolicy Bypass -File .\tools\verify-safe.ps1` after source changes; review `REVIEW` findings and stop on a `FORBIDDEN` finding.

If the optional ImGui/OpenGL backend cannot initialize on a machine, the client falls back to `SafeMenuScreen`, a vanilla-rendered local menu. The fallback lists module state and allows clicking rows to toggle modules. The ImGui Java/native dependencies remain optional runtime attack surface and should be tested only in an isolated environment.

## Run and build

Use JDK 21 and a clean, isolated Minecraft test instance. The development client can be started with:

```text
run.bat
```

Build the Satur Client mod jar with:

```text
gradlew build
```

The build has not been executed as part of the safety review. Inspect dependency hashes and build inside a disposable VM or Windows Sandbox before using a compiled jar with any account.

## API and modules

See [`docs/CUSTOM_API.md`](docs/CUSTOM_API.md) for the local `ClientApi`, `CustomModule`, and `ModuleLoader` entry points. The bundled module manifest remains local and is not downloaded at runtime.
