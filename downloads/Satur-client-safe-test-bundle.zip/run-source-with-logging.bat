@echo off
setlocal EnableExtensions
cd /d "%~dp0source"
set "GRADLE_USER_HOME=%~dp0source\.gradle-home"

if not exist "gradlew.bat" (
  echo Source project is missing gradlew.bat.
  pause
  exit /b 1
)

for /f "delims=" %%J in ('powershell -NoProfile -Command "$x=Get-ChildItem -LiteralPath '%~dp0java' -Filter java.exe -Recurse -File -ErrorAction SilentlyContinue ^| Select-Object -First 1; if($x){$x.Directory.Parent.FullName}"') do set "JAVA_HOME=%%J"
if not defined JAVA_HOME echo Using Java from PATH.
if not exist "%~dp0logs" mkdir "%~dp0logs"
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set "STAMP=%%T"
set "LOG=%~dp0logs\run_%STAMP%.log"
echo Logging to %LOG%

call gradlew-safe.bat runClient --console=plain > "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
if exist "run\logs\latest.log" copy /y "run\logs\latest.log" "%~dp0logs\run_%STAMP%_latest.log" >nul
if exist "run\crash-reports" for /f "delims=" %%C in ('dir /b /o-d "run\crash-reports\*.txt" 2^>nul') do copy /y "run\crash-reports\%%C" "%~dp0logs\run_%STAMP%_crash.txt" >nul & goto :done
:done
echo Exit code %RC%. Logs are in %~dp0logs
if not "%RC%"=="0" pause
exit /b %RC%
