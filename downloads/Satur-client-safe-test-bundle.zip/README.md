# Satur Client safe test bundle

This bundle contains the compiled Satur Beta JAR, its clean source archive, static verification tools, and a logging launcher for the included source project.

## Important limits

Minecraft is proprietary software, so this bundle does not redistribute the Minecraft client. The Temurin script downloads Java 21 from the official Eclipse Adoptium API and verifies the archive SHA-256 before extraction. Install Minecraft and Fabric from their official sources inside the disposable test environment.

No tool can prove that a client is malware-free. Test with no personal files or normal account, and keep the exact hashes in your notes.

## Verify the artifacts

Run PowerShell from this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\verify-artifacts.ps1
powershell -ExecutionPolicy Bypass -File .\tools\verify-safe.ps1 -SourceRoot .\source\src\main\java
```

The verifier should report no forbidden process, native-loader, raw-network, credential, or self-destruct patterns. Reflection and GLFW use may still appear as review-only findings.

## Install Java 21

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\download-temurin21.ps1
```

Record the SHA-256 printed by the script. The script uses the official Adoptium API and rejects an unexpected package host or a checksum mismatch.

## Run with logs

After installing Minecraft/Fabric in the disposable environment, extract or use the included `source` project and run:

```bat
run-source-with-logging.bat
```

Logs are written to `logs\run_<timestamp>.log`. The launcher also copies Minecraft's `latest.log` and the newest crash report when available.

If you run Gradle manually from `source`, use the included wrapper that keeps its cache local to the project:

```bat
gradlew-safe.bat build
```

## JAR test

The compiled JAR is a Fabric mod, not a standalone executable. Put it in the `mods` folder of a matching Fabric 1.21.11 client, then launch Minecraft. The native Satur GUI opens with Right Shift.
